﻿function initGUI()
	drawMainTele()
	drawTeleWizard()
	addEventHandler ( "onClientGUIClick", teleManager, teleManagerClick )
	addEventHandler ( "onClientGUIClick", teleWizard, teleWizardClick )
	checkPermissions()
end

function drawMainTele()
	local wX = 0.2
	local wY = 0.25
	local wWidth = 0.45
	local wHeight = 0.45
	teleManager = guiCreateWindow ( wX, wY, wWidth, wHeight, "Gerenciador de teleportes", true ) guiWindowSetSizable ( teleManager, false ) guiSetVisible ( teleManager, false )
	
	teleManagerClose = guiCreateButton ( 0.25, 0.85, 0.5, 0.1, "Fechar", true, teleManager )
	teleManagerAddTele = guiCreateButton ( 0.7, 0.15, 0.25, 0.1, "Add teleporte", true, teleManager )
	teleManagerDeleteTele = guiCreateButton ( 0.7, 0.3, 0.25, 0.1, "Deletar teleporte", true, teleManager )
	teleManagerUseTele = guiCreateButton ( 0.7, 0.6, 0.25, 0.15, "Usar teleporte", true, teleManager )
	
	listLabel = guiCreateLabel ( 0.05, 0.1, 0.5, 0.1, "Disponíveis:", true, teleManager )
	
	list = guiCreateGridList ( 0.05, 0.15, 0.6, 0.6, true, teleManager ) guiGridListSetSortingEnabled ( list, false )
	listDescColumn = guiGridListAddColumn ( list, "Descrição", 0.6 )
	listTypeColumn = guiGridListAddColumn ( list, "Tipo", 0.3 )
end

function drawTeleWizard()
	local wX = 0.2
	local wY = 0.25
	local wWidth = 0.26
	local wHeight = 0.45
	teleWizard = guiCreateWindow ( wX, wY, wWidth, wHeight, "Teleport Wizard", true ) guiWindowSetSizable ( teleWizard, false ) guiSetVisible ( teleWizard, false )
	
	teleWizardClose = guiCreateButton ( 0.15, 0.85, 0.7, 0.1, "Fechar", true, teleWizard )
	teleWizardAddTele = guiCreateButton ( 0.35, 0.74, 0.3, 0.07, "Add teleporte", true, teleWizard )
	teleWizardGetPos = guiCreateButton ( 0.6, 0.295, 0.2, 0.05, "Posição atual", true, teleWizard )
	teleWizardXLabel = guiCreateLabel ( 0.05, 0.1, 0.3, 0.1, "Teleporte X:", true, teleWizard )
	teleWizardYLabel = guiCreateLabel ( 0.05, 0.2, 0.3, 0.1, "Teleporte Y:", true, teleWizard )
	teleWizardZLabel = guiCreateLabel ( 0.05, 0.3, 0.3, 0.1, "Teleporte Z:", true, teleWizard )
	teleWizardRotLabel = guiCreateLabel ( 0.6, 0.12, 0.3, 0.08, "Rotação:", true, teleWizard )
	teleDescriptionLabel = guiCreateLabel ( 0.05, 0.45, 0.9, 0.1, "Teleport Description (Needs to fit inside GUI)", true, teleWizard )
	teleTypeLabel = guiCreateLabel ( 0.05, 0.6, 0.9, 0.1, "Tipo", true, teleWizard )
	teleWizardVehOnly = guiCreateRadioButton ( 0.05, 0.64, 0.2, 0.06, "Apenas veículo", true, teleWizard )
	teleWizardFootOnly = guiCreateRadioButton ( 0.35, 0.64, 0.2, 0.06, "Apenas a pé", true, teleWizard )
	teleWizardBoth = guiCreateRadioButton ( 0.65, 0.64, 0.2, 0.06, "Ambos", true, teleWizard )
	teleWizardXBox = guiCreateEdit ( 0.22, 0.095, 0.3, 0.05, "", true, teleWizard )
	teleWizardYBox = guiCreateEdit ( 0.22, 0.192, 0.3, 0.05, "", true, teleWizard )
	teleWizardZBox = guiCreateEdit ( 0.22, 0.295, 0.3, 0.05, "", true, teleWizard )
	teleWizardDescBox = guiCreateEdit ( 0.05, 0.5, 0.8, 0.05, "Descrição do teleporte:", true, teleWizard )
	
	teleWizardRotBox = guiCreateEdit ( 0.6, 0.192, 0.1, 0.05, "", true, teleWizard )
	

end

addEventHandler ( "onClientResourceStart", getResourceRootElement ( getThisResource() ), initGUI )