﻿
--[[
	* Script made by Stanley Sathler, also known as Sathler
	* Function: sets the stats of all players to "hitman" skills
]]--

-- Why 69 to 79? It's because the skills are between these numbers.

-- List of weapons that should not be double (two weapons)
-- 69: normal pistol
-- 73: sawn-off
-- 75: uzi and tec-9

function setWeaponStatToHitman()
	for i, player in ipairs(getElementsByType("player")) do
		local count = 69
		while count <= 79 do
			if count == 69 or count == 73 or count == 75 then
				setPedStat(player, count, 998)
				count = count+1
			else
				setPedStat(player, count, 999)
				count = count+1
			end
		end
	end
end
addEventHandler("onResourceStart", resourceRoot, setWeaponStatToHitman)
addEventHandler("onPlayerLogin", getRootElement(), setWeaponStatToHitman)


function f_setPremiumKit(thePlayer)
	if getElementData(thePlayer, "DW-Administrador") == true or getElementData(thePlayer, "DW-Moderador") == true then
		setElementData(thePlayer, "MAX_Slots", 16)
		setElementData(thePlayer, "MP5", 1)
		setElementData(thePlayer, "Munição p/ MP5", 100)
		setElementData(thePlayer, "Garrafa D'água", 1)
		setElementData(thePlayer, "Pizza", 1)
		setElementData(thePlayer, "Mapa", 1)
		setElementData(thePlayer, "GPS", 1)
		setElementData(thePlayer, "Relógio", 1)
	end
end
addCommandHandler("itens", f_setPremiumKit)