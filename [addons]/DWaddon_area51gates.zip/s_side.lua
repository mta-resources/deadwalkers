Gate_Back = createObject ( 974, 286, 1821.3, 19.9, 0, 0, 89.5 )
Gate_Front = createObject ( 974, 134.2, 1942.2, 21.6, 0, 0, 180 )
setElementDoubleSided(Gate_Back,true)
setElementDoubleSided(Gate_Front,true)
createObject(16094,191.10001,1870.6,21.5) -- reconstructs main 51's fence


-- Gate back functions
function Toggle_GateBack(toggle,time)
	local x,y,z = 286, 1821.3, 19.9
	if toggle == true and getElementData(Gate_Back,"Gate:Animation") == false then
		setElementData(Gate_Back,"Gate:Animation",true)
		moveObject(Gate_Back,time,x,y+12.5,z)
		setTimer ( removeElementData, time, 1,Gate_Back,"Gate:Animation")
		setTimer ( Toggle_GateBack, time+1000, 1,false,time )
	elseif toggle == false and getElementData(Gate_Back,"Gate:Animation") == false then
		setElementData(Gate_Back,"Gate:Animation",true)
		moveObject(Gate_Back,time,x,y,z)
		setTimer ( removeElementData, time, 1,Gate_Back,"Gate:Animation")
	end
end	

GateBack_ColShape = createColSphere ( 285.9150390625, 1820.796875, 17.640625,7 )	
	
function GateBack_ColShapeEnter( theElement, matchingDimension )
 if getElementType ( theElement ) == "player" then  
	Toggle_GateBack(true,5000)
    end
end
addEventHandler("onColShapeHit",GateBack_ColShape,GateBack_ColShapeEnter)

function GateBack_ColShape_Leave( theElement, matchingDimension )
 if getElementType ( theElement ) == "player" then
	Toggle_GateBack(false,5000)
    end
end
addEventHandler("onColShapeLeave",GateBack_ColShape,GateBack_ColShape_Leave)


-- Gate front functions
function Toggle_GateFront(toggle,time)
	local x,y,z = 134.2, 1942.2, 21.6
	if toggle == true and getElementData(Gate_Front,"Gate:Animation") == false then
		setElementData(Gate_Front,"Gate:Animation",true)
		moveObject(Gate_Front,time,x-12.5,y,z)
		setTimer ( removeElementData, time, 1,Gate_Front,"Gate:Animation")
		setTimer ( Toggle_GateFront, time+1000, 1,false,time )
	elseif toggle == false and getElementData(Gate_Front,"Gate:Animation") == false then
		setElementData(Gate_Front,"Gate:Animation",true)
		moveObject(Gate_Front,time,x,y,z)
		setTimer ( removeElementData, time, 1,Gate_Front,"Gate:Animation")
	end
end	

GateFront_ColShape = createColSphere ( 135.173828125, 1941.744140625, 19.303453445435,7 )	
	
function GateFront_ColShapeEnter( theElement, matchingDimension )
 if getElementType ( theElement ) == "player" then  
	Toggle_GateFront(true,5000)
    end
end
addEventHandler("onColShapeHit",GateFront_ColShape,GateFront_ColShapeEnter)

function GateFront_ColShape_Leave( theElement, matchingDimension )
 if getElementType ( theElement ) == "player" then
	Toggle_GateFront(false,5000)
    end
end
addEventHandler("onColShapeLeave",GateFront_ColShape,GateFront_ColShape_Leave)
	
	
	