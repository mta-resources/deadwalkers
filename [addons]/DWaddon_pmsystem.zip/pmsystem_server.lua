﻿function privateMessage(thePlayer,commandName,sendToName,...)
	local pmWords = { ... }
	local pmMessage = table.concat( pmWords, " " )
	if sendToName then
		if (getPlayerFromParticalName (sendToName)) then
		toPlayer = (getPlayerFromParticalName (sendToName))
			if not (toPlayer == thePlayer) then
				if not (pmMessage == "") then
					outputChatBox("<-- #FFFFFF[PM] Mensagem enviada a(o) #ff9900" .. getPlayerName(toPlayer) .. "#FFFFFF: " .. pmMessage, thePlayer, 255, 255, 255, true)
					outputChatBox("--> #FFFFFF[PM] Mensagem de #ff9900" .. getPlayerName(thePlayer) .. "#FFFFFF: " .. pmMessage, toPlayer, 255, 255, 255, true)
					outputChatBox("#FFFFFF[PM] #00FF00 Use /responder [texto] para responder", toPlayer, 255, 255, 255, true)
					setElementData(thePlayer,"pmPartner",toPlayer)
					setElementData(toPlayer,"pmPartner",thePlayer)
				else
					outputChatBox("#FF6A00[PM] Use #FFFFFF/pm [nick] [texto] #FF6A00para mandar uma mensagem privada.", thePlayer, 255, 255, 255, true)
					return false
				end
			else
				outputChatBox("#FF6A00[PM] Você não pode enviar PM's para si mesmo.", thePlayer, 255, 255, 255, true)
				return false
			end
		else
			outputChatBox("#FFFFFF[PM]#00ccff Este Player não está no servidor! #FFFF00[#ff9900"..sendToName.."#FFFF00]", thePlayer, 255, 255, 255, true)
			return false
		end
	else
		outputChatBox("#FFFFFF[PM]Use:#ff9900 /pm [Nick] [Texto]", thePlayer, 255, 255, 255, true)
		return false
	end
end
addCommandHandler("pm", privateMessage)

function privateMessageReply(thePlayer,commandName,...)
	local pmWords = { ... }
	local pmMessage = table.concat( pmWords, " " )
	local toPlayer = getElementData(thePlayer,"pmPartner")
			if toPlayer then 
				if not (pmMessage == "") then
					outputChatBox("<-- #FF6A00[PM] Mensagem enviada a(o) #FFFFFF" .. getPlayerName(toPlayer) .. "#FF6A00: " .. pmMessage, thePlayer, 255, 255, 255, true)
					outputChatBox("--> #FF6A00[PM] Resposta de #FFFFFF" .. getPlayerName(thePlayer) .. "#FF6A00: " .. pmMessage, toPlayer, 255, 255, 255, true)
					outputChatBox("#FF6A00[PM] Use #FFFFFF/responder [texto] #FF6A00para responder", toPlayer, 255, 255, 255, true)
				else
					outputChatBox("#FF6A00[PM] Use #FFFFFF/responder [texto]", thePlayer, 255, 255, 255, true)
					return false
				end
			else
			outputChatBox("#FF6A00[PM] Não há ninguém para ser respondido.", thePlayer, 255, 255, 255, true)
			end
end
addCommandHandler("responder", privateMessageReply)


function getPlayerFromParticalName(thePlayerName)
	local thePlayer = getPlayerFromName(thePlayerName)
	if thePlayer then
		return thePlayer
	end
	for _,thePlayer in ipairs(getElementsByType("player")) do
		if string.find(string.gsub(getPlayerName(thePlayer):lower(),"#%x%x%x%x%x%x", ""), thePlayerName:lower(), 1, true) then
			return thePlayer
		end
	end
return false
end

