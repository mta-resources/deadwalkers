---------------------------------------------------------------
---------------------------------------------------------------
--* Skype: Niko.Analke                                              
---------------------------------------------------------------

function sexovaginal(quitType)
     if quitType == "Quit" or quitType == "Timed out" then
       local tempo = getElementData ( source, "tempodosexo" )
       if tempo then
        local acon = getPlayerAccount(source)
         if (acon) then
         setAccountData(acon,'blood',-5)
         setAccountData ( acon, "tempodosexo", false )
         end 
       end 
     end
end
--addEvent( "sexoatempo", true )
addEventHandler ( "onPlayerQuit", getRootElement(), sexovaginal )

