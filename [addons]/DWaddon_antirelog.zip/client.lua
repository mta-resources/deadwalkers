---------------------------------------------------------------
---------------------------------------------------------------
--* MTADAYZ.COM
--* MTADAYZ.COM         
--* MTADAYZ.COM         
--* MTADAYZ.COM                             
---------------------------------------------------------------
function playerGetDamageDayZ ( attacker, weapon, bodypart, loss )
   if not getElementData ( source, "tempodosexo" ) then
     if weapon and weapon > 1 and attacker and getElementType(attacker) == "player" then
      setTimer (deslogger, 10000, 1, source)
      setTimer ( setElementData, 10000, 1, source, "tempodosexo", false )
      setElementData ( source, "tempodosexo", true )
      outputChatBox ( "Você recebeu dano! Não deslogue em 10 segundos ou você irá morrer!", source, 255, 5, 0 )
     end
   end
end
addEventHandler ( "onClientPlayerDamage", getLocalPlayer (), playerGetDamageDayZ )

function deslogger(ps) 
    outputChatBox ( "Você já pode deslogar.", ps, 255, 5, 0 )
end 

