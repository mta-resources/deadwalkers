﻿-- Criado por: Stanley Sathler
-- Para: DayZ
-- Função: Substitui os veículos, instalando modelos customizados (famosos "mods")

vehicles = {
	{ "barracks", 433 },
	{ "bobcat", 422 },
	{ "patriot", 470 },
	{ "maverick", 487 },
	{ "pmaverick", 497 }
}

function replaceVehicles()
    for index, vehicle in ipairs(vehicles) do
        txd = engineLoadTXD ( "models/"..vehicles[index][1].. ".txd")
        engineImportTXD ( txd, vehicles[index][2] )
        dff = engineLoadDFF ( "models/"..vehicles[index][1].. ".dff", vehicles[index][2] )
        engineReplaceModel ( dff, vehicles[index][2] )
    end
end
addEventHandler("onClientResourceStart", resourceRoot, replaceVehicles)

function getPlayerCoordinates()
	local x, y, z = getElementPosition(localPlayer)
	outputChatBox("X: "..x.." | Y: "..y.." | Z: "..z)
end
addCommandHandler("getmypos", getPlayerCoordinates)