--\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
-- GlobalChat MTA:DayZ addon 1.1.1
-- Made by -ffs-Sniper
-- You are free to edit this addon
--///////////////////////////////////

--Define your desired chat key
GlobalChatKey = "m"

addEventHandler( "onClientResourceStart", getResourceRootElement ( ),
	function ( )
		bindKey ( GlobalChatKey, "down", "chatbox", "globalchat" )
		outputChatBox ( "[INFO] Use a tecla #FFFFFF" .. string.upper ( GlobalChatKey ) .. "#FF6A00 para usar o chat global." , 255, 106, 0, true )
	end
)